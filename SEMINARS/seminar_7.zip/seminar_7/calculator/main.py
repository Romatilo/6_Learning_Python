from controller import process_data


def main():
    process_data()


if __name__ == '__main__':
    main()
